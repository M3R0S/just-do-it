import { AboutPageAsync } from './ui/AboutPage.async';

export {
    AboutPageAsync as AboutPage,
};
