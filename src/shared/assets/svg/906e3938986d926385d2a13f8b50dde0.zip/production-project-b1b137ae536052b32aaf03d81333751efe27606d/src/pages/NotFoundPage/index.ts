import { NotFoundPage } from './ui/NotFoundPage';

export {
    NotFoundPage,
};
